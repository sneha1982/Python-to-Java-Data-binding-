
/* 
 * Based on examples at https://docs.oracle.com/javase/tutorial/networking/datagrams/clientServer.html and http://www.heimetli.ch/udp/UDPServer.html
 *
 * Run by performing:
 * $ sudo apt-get install default-jdk
 * $ javac UDPExample.java
 * $ java UDPExample & python UDPExample.py
 * 
 * Result should be something like:
 * java UDPExample & python UDPExample.py
 * [1] 24757
 * Server loop running in thread:  Thread-1
 * Starting Java server
 * Python got data: Hello Python 1
 * Java got data: Hello Java 2
 * Python got data: Hello Python 2
 * Java got data: Hello Java 3
 * Python got data: Hello Python 3
 * Shutting down Python server
 * Shutting down Java server
 * [1]+  Done                    java UDPExample
 */
import java.io.*;
import java.net.*;
import java.util.*;

public class UDPExample {
    /*
     * This starts up the server, sends a few messages and then shuts the server
     * down. You probably don't want this in a 'main' function, but it gives you the
     * idea of how to start the server. You'll need to expose the UDPExampleThread
     * class to whoever starts the server.
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        System.out.println("Starting Java server");
        UDPExampleThread example = new UDPExampleThread();
        example.start();
        example.sendMessage("Hello Python 1");
        Thread.sleep(10000);
        example.sendMessage("Hello Python 2");
        Thread.sleep(10000);
        example.sendMessage("Hello Python 3");
        Thread.sleep(10000);
        System.out.println("Shutting down Java server");
        example.close();
    }
}

class UDPExampleThread extends Thread {
    private final static int PACKETSIZE = 100;
    private final static int JAVA_SERVER_PORT = 4445;
    private final static String PYTHON_SERVER_HOST = "localhost";
    private final static int PYTHON_SERVER_PORT = 4446;

    protected DatagramSocket rxsocket = null;
    protected DatagramSocket txsocket = null;
    protected InetAddress txhost = null;
    private volatile boolean StopServer = false;

    /*
     * Put the code you want to do something based on when you get data here.
     */
    private void onData(String data) {
        String toprint = "Java got data: " + data;
        System.out.println(toprint);
    }

    public UDPExampleThread() throws IOException {
        rxsocket = new DatagramSocket(JAVA_SERVER_PORT);
        rxsocket.setSoTimeout(250);
        txhost = InetAddress.getByName(PYTHON_SERVER_HOST);
        txsocket = new DatagramSocket();
    }

    public void sendMessage(String message) throws IOException {
        byte[] data = message.getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, txhost, PYTHON_SERVER_PORT);
        txsocket.send(packet);
    }

    public void run() {
        try {
            while (!StopServer) {
                byte buf[] = new byte[PACKETSIZE];
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                try {
                    rxsocket.receive(packet);
                    String data = new String(packet.getData(), 0, packet.getLength());
                    onData(data);
                } catch (SocketTimeoutException e) {
                }
            }
            rxsocket.close();
        } catch (IOException e) {
            System.out.println("IOException");
        }
    }

    public void close() {
        StopServer = true;
    }
}